Quick Start (in windows system):
Unzip the filebrowser-windows.zip to a folder, 
double click filebrowser.exe in the folder to start the http server, 
then in your browser, visit 192.168.x.x:8080 (or 127.0.0.1:8080), input default account admin : admin to login, 
double click the .srt file (with yellow icon) in the list to start PDJ media repeater. 
Have fun!

快速启动（windows操作系统为例）：
解压缩下载的filebrowser-windows.zip到一个文件夹,
双击该文件夹里的filebrowser.exe 以启动http服务器。
在浏览器里访问192.168.x.x:8080 (或者127.0.0.1:8080)，输入默认用户名 admin 和密码 admin 来登录。
双击页面中黄色图标的.srt来启动PDJ媒体复读机。
使用愉快！永久免费！


===========================================
使用介绍：
https://www.bilibili.com/video/BV1h1seeqEav/

update link / 更新地址：
https://github.com/niubility000/PDJ-Media-Repeater
https://note.youdao.com/s/MI81scdr

媒体和字幕资源共享：
https://pan.baidu.com/s/1EMm3C3rcWnqqxutBV9W0Mw?pwd=s0wa


===========================================
Set up and start Filebrowser using the command line, taking a Windows computer as an example / 用命令行设置和启动Filebrowser，以windows电脑为例:

Place filebrowser.exe in a folder, such as d:\filebrowser. / 将filebrowser.exe 放入一个文件夹，例如d:\filebrowser。

Then operate in the Dos (or windows terminal) / 然后在dos窗口操作：
cd d:\filebrowser          //Navigate to this folder / 进入此文件夹
.\filebrowser.exe -d filebrowser.db config init    //Automatically generate the database file "filebrowser.db" in d:\filebrowser / 自动在d:\filebrowser\ 生成数据库文件 "filebrowser.db"
.\filebrowser.exe -d filebrowser.db users add kkk 123456 --perm.admin   //Add a new administrator account, kkk:123456. You can change the username and password as you like. / 添加新的管理员帐户，kkk:123456，用户名密码可以自己改。
.\filebrowser.exe -d filebrowser.db config set --port 1234                 //Set the port number, which can be modified as needed. / 设置端口号，可以自己修改。
.\filebrowser.exe -d filebrowser.db config set --root d:/     //Set the root directory accessible by Filebrowser, such as the D drive of the computer. / 设置filebrowser能访问的根目录，比如电脑的D盘。

运行：
.\filebrowser.exe -d .\filebrowser.db --disable-preview-resize --cache-dir .\cache         // Then access 127.0.0.1:1234, 192.168.x.x:1234, or public IP:1234 in your browser. / 然后在浏览器中访问127.0.0.1:1234, 192.168.x.x:1234或公网IP:1234即可，

To stop the Filebrowser service / 停止filebrowser服务：
ctrl+c


===========================================
File Requirements
Media files must be in .mp3 or .mp4 format (file extensions must be lowercase).
.srt subtitle files must have the same name as the media file (case sensitive) and be placed in the same folder.
If a .srt subtitle file contains non-English characters, it must use UTF-8 encoding; otherwise, the text will be garbled. If it is not in UTF-8, you can open the subtitle file with Notepad on a Windows computer, select "Save As", and choose UTF-8 encoding to change it.

文件要求
媒体文件需要是 .mp3 或 .mp4（后缀名要小写）。
.srt 字幕文件需要与媒体文件同名，并在同一文件夹内。
如果 .srt 字幕文件中有非英语字符，请使用 utf8 编码，否则会乱码。如果不是utf8，可以用windows电脑的记事本打开字幕文件，选择另存为，选择utf8编码即可更改。
