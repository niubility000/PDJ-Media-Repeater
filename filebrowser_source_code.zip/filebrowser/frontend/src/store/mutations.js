import * as i18n from "@/i18n";
import moment from "moment/min/moment-with-locales";

const mutations = {
  closeHovers: (state) => {
    state.prompts.pop();
  },
  saveScrollPosition: (state, { path, scrollTop }) => {
    if (!state.scrollPositions) {
      state.scrollPositions = {};
    }
    state.scrollPositions[path] = scrollTop;
  },
  getScrollPosition: (state, path) => {
    return state.scrollPositions?.[path] || 0;
  },
  clearScrollPosition: (state, path) => {
    if (state.scrollPositions) {
      delete state.scrollPositions[path];
    }
  },
  setLastOpenedIndex: (state, index) => {
    state.lastOpenedIndex = index;
  },
  clearLastOpenedIndex: (state) => {
    state.lastOpenedIndex = null;
  },
  setParentPathIndex: (state, { index, path }) => {
    state.parentPathIndex = index;
    state.parentPath = path;
  },
  clearParentPathIndex: (state) => {
    state.parentPathIndex = null;
    state.parentPath = null;
  },
  toggleShell: (state) => {
    state.show = null;
    state.showShell = !state.showShell;
  },
  showHover: (state, value) => {
    if (typeof value !== "object") {
      state.prompts.push({
        prompt: value,
        confirm: null,
        action: null,
        props: null,
      });
      return;
    }

    state.prompts.push({
      prompt: value.prompt, // Should not be null
      confirm: value?.confirm,
      action: value?.action,
      props: value?.props,
    });
  },
  showError: (state) => {
    state.prompts.push("error");
  },
  showSuccess: (state) => {
    state.prompts.push("success");
  },
  setLoading: (state, value) => {
    state.loading = value;
  },
  setReload: (state, value) => {
    state.reload = value;
  },
  setUser: (state, value) => {
    if (value === null) {
      state.user = null;
      return;
    }

    let locale = value.locale;

    if (locale === "") {
      locale = i18n.detectLocale();
    }

    moment.locale(locale);
    i18n.default.locale = locale;
    state.user = value;
  },
  setJWT: (state, value) => (state.jwt = value),
  multiple: (state, value) => (state.multiple = value),
  addSelected: (state, value) => state.selected.push(value),
  removeSelected: (state, value) => {
    let i = state.selected.indexOf(value);
    if (i === -1) return;
    state.selected.splice(i, 1);
  },
  resetSelected: (state) => {
    state.selected = [];
  },
  updateUser: (state, value) => {
    if (typeof value !== "object") return;

    for (let field in value) {
      if (field === "locale") {
        moment.locale(value[field]);
        i18n.default.locale = value[field];
      }

      state.user[field] = value[field];
    }
  },
  updateShowSubConvertor: (state, value) => {
    state.showSubConvertor = value;
  },
  updateShowWordReciter: (state, value) => {
    state.showWordReciter = value;
  },
  updateRequest: (state, value) => {
    const selectedItems = state.selected.map((i) => state.req.items[i]);
    state.oldReq = state.req;
    state.req = value;
    state.selected = [];

    if (!state.req?.items) return;
    state.selected = state.req.items
      .filter((item) => selectedItems.some((rItem) => rItem.url === item.url))
      .map((item) => item.index);
  },
  updateClipboard: (state, value) => {
    state.clipboard.key = value.key;
    state.clipboard.items = value.items;
    state.clipboard.path = value.path;
  },
  resetClipboard: (state) => {
    state.clipboard.key = "";
    state.clipboard.items = [];
  },
  setUploadSpeed: (state, value) => {
    state.upload.speedMbyte = value;
  },
  setETA(state, value) {
    state.upload.eta = value;
  },
  resetUpload(state) {
    state.upload.uploads = {};
    state.upload.queue = [];
    state.upload.progress = [];
    state.upload.sizes = [];
    state.upload.id = 0;
    state.upload.speedMbyte = 0;
    state.upload.eta = 0;
  },
};

export default mutations;
