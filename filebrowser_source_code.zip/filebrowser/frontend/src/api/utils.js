import store from "@/store";
import { renew, logout } from "@/utils/auth";
import { baseURL } from "@/utils/constants";
import { encodePath } from "@/utils/url";

export async function fetchURL(url, opts, auth = true) {
  opts = opts || {};
  opts.headers = opts.headers || {};

  let { headers, ...rest } = opts;
  let res;
  try {
    if (
      window.localStorage.getItem("isOffline") &&
      window.localStorage.getItem("isOffline") == "1" &&
      (((Number(window.localStorage.getItem("isReminder")) == 1 ||
        Number(window.localStorage.getItem("isWordReciter")) == 1 ||
        Number(window.localStorage.getItem("isMistakeBook")) == 1) &&
        window.localStorage.getItem("lastOnLineReminderToken") ==
          window.localStorage.getItem("lastRawToken")) ||
        (!Number(window.localStorage.getItem("isReminder")) == 1 &&
          !Number(window.localStorage.getItem("isWordReciter")) == 1 &&
          !Number(window.localStorage.getItem("isMistakeBook")) == 1 &&
          window.localStorage.getItem("lastOnLineRepeaterToken") ==
            window.localStorage.getItem("lastRawToken")))
    )
      res = await fetch(`${baseURL}${url}`, {
        headers: {
          "X-Auth": store.state.jwt,
          ...headers,
        },
        ...rest,
      });
    else
      res = await fetch(`${baseURL}${url}`, {
        headers: {
          "Cache-Control": "no-cache",
          "X-Auth": store.state.jwt,
          ...headers,
        },
        ...rest,
      });
  } catch {
    const onOffline = Number(window.localStorage.getItem("isOffline")) == 1;
    if (onOffline) {
      return {
        json: () => Promise.resolve({}),
        text: () => Promise.resolve(""),
        ok: false,
        status: 0,
      };
    } else {
      const error = new Error("No connection");
      error.status = 0;
      throw error;
    }
  }

  if (auth && res.headers.get("X-Renew-Token") === "true") {
    await renew(store.state.jwt);
  }

  if (res.status < 200 || res.status > 299) {
    const error = new Error(await res.text());
    error.status = res.status;

    if (auth && res.status == 401) {
      logout();
    }

    throw error;
  }

  return res;
}

export async function fetchJSON(url, opts) {
  const res = await fetchURL(url, opts);

  if (res.status === 200) {
    return res.json();
  } else {
    throw new Error(res.status);
  }
}

export function removePrefix(url) {
  url = url.split("/").splice(2).join("/");

  if (url === "") url = "/";
  if (url[0] !== "/") url = "/" + url;
  return url;
}

export function createURL(endpoint, params = {}, auth = true) {
  let prefix = baseURL;
  if (!prefix.endsWith("/")) {
    prefix = prefix + "/";
  }
  const url = new URL(prefix + encodePath(endpoint), origin);

  const searchParams = {
    ...(auth && { auth: store.state.jwt }),
    ...params,
  };

  for (const key in searchParams) {
    url.searchParams.set(key, searchParams[key]);
  }

  return url.toString();
}
