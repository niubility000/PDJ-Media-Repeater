package main

import (
	"github.com/filebrowser/filebrowser/v2/cmd"
)

func main() {
	cmd.Execute()
}
