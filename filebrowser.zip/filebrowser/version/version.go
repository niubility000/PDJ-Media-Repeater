package version

var (
	// Version is the current File Browser version.


	Version = "- PDJ Media Repeater-2.0"

	// CommitSHA is the commmit sha.
	CommitSHA = "(unknown)"
)
